import json
import unittest
from .wishlist_api import app

class TestWishListAPI(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()

    def test_get_wishlist_id(self):
        response = self.app.get('/wishlist?id=1000')
        self.assertEqual(response.status_code, 200)
        
    def test_get_user_id(self):
        response = self.app.get('/wishlist?user_id=1000')
        
    def test_get_wishlist_name(self):
        response = self.app.get('/wishlist?wishlist_name=Name')
        
if __name__ == '__main__':
    unittest.main()    
    